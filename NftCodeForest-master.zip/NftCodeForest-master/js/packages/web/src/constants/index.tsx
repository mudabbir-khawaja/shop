import { WRAPPED_SOL_MINT } from '@oyster/common';

export * from './labels';
export * from './style';

export const QUOTE_MINT = WRAPPED_SOL_MINT;
